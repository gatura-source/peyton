The GUI application is developed to run on Linux systems
The application requires Python3 to execute successfully.
All the errors are displayed on the terminal 

The requirements are in the requirements.txt